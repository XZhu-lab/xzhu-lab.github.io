function [nsf,mean_sf,std_sf] = NSF(sf)
mean_sf = mean(mean(sf));
std_sf = std(std(sf));

nsf = (sf-mean_sf)./std_sf;

