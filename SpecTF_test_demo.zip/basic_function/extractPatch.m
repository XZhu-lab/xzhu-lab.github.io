function [patch] = extractPatch(image, coordinates, patchSize)
% return a patch, centered at a given pixel from given image 
% [patch] = DictTrain_Aplus(image, patchSize, padding)
%
%
%     ------------------
%     --- parameters ---
%     ------------------
%     image: 
%     give an image of size [height, width, spectral dimensions]
%     pixel: 
%     coordinates of a pixel around which a patch should be extracted [height, width]
%     patchSize: 
%     size of patch (i.e. [1,1], [3,3], [5,5])
%     padding: 
%     string with expected padding 'symmetric', 'replicate'
%
%
%     ------------------
%     ----- output -----
%     ------------------
%     patch:
%     return the extracted patch in a matrix which contains the pixel
%     values in a column (i.e. size = [spectral dimension,
%     prod(patchSize)]) which correspond to the values of the pixels from
%     top left to bottom right (left to right, down, left to right,
%     down,...)


patch = zeros(size(image,3), prod(patchSize));
counter = 0;
for h = -(floor(patchSize(1)/2)):floor(patchSize(1)/2)
   for  w = -(floor(patchSize(2)/2)):floor(patchSize(2)/2)
       counter = counter + 1;
       for c = 1:size(image,3)
           patch(c, counter) = image(coordinates(1)+h, coordinates(2)+w, c);
       end
   end
end



