function [SpectralDegradation] = SRFcal(SRF_m,SRF_h)

wavelengths = SRF_m(:,1);
[~, N] = size(SRF_h); 
[~, M] = size(SRF_m);

srf_h = SRF_h(:,2:N); srf_h = srf_h';
srf_m = SRF_m(:,2:M); srf_m = srf_m';

[N, ~] = size(srf_h); 
[M, ~] = size(srf_m);

%%% Initialize the spectral degradation matrix
D = zeros(N, M);      


for j = 1:M
    for i = 1:N
        D(i, j) = trapz(wavelengths, srf_h(i, :) .* srf_m(j, :));
    end
    D(:, j) = D(:, j) / sum(D(:, j));
end

SpectralDegradation = D;
end