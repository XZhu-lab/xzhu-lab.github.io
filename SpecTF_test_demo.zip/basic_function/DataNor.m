function DataNor(msi,hsi)

%%% Feature extraction

[nsf_m1,mean_m,std_m]= NSF(msi);
[nsf_h1,mean_h,std_h] = NSF(hsi);

msi = nsf_m1; hsi = nsf_h1;
save('msi_hsi_01.mat','msi','hsi');
%转置
msi_t = permute(msi,[2,1,3]);
hsi_t= permute(hsi,[2,1,3]);
msi = msi_t; hsi = hsi_t;
save('msi_hsi_02.mat','msi','hsi');

msi_t = imrotate3(msi,90,[0,0,1],'crop');
hsi_t = imrotate3(hsi,90,[0,0,1],'crop');
msi = msi_t; hsi = hsi_t;
save('msi_hsi_03.mat','msi','hsi');

msi_t = imrotate3(msi,180,[0,0,1],'crop');
hsi_t = imrotate3(hsi,180,[0,0,1],'crop');
msi = msi_t; hsi = hsi_t;
save('msi_hsi_04.mat','msi','hsi');