function Build_dataset(m1,h1,datapath,dicpath,param)

disp('************** Building training sets **************');
DataNor(m1,h1); 
nTR_DM= [500, 1000]; nTR_DH = [param.samples, 5000];

patchSize = param.patchsize;
b_m = param.bm; b_h = param.bh;

scale = [1,param.w];

Database1 = dir([datapath,'\msi_hsi_01.mat']);
Database2 = dir([datapath,'\msi_hsi_02.mat']);
Database3 = dir([datapath,'\msi_hsi_03.mat']);
Database4 = dir([datapath,'\msi_hsi_04.mat']);
Database = [Database1;Database2;Database3;Database4];   

DBsize = size(Database,1);

TR1size = floor(DBsize/4);
TR2size = floor(DBsize/4);
TR3size = floor(DBsize/4);
TR4size = DBsize - (TR1size + TR2size + TR3size);

TR1(TR1size).TRname = 'placeholder';
TR2(TR2size).TRname = 'placeholder';
TR3(TR3size).TRname = 'placeholder';
TR4(TR4size).TRname = 'placeholder';

for i = 1:DBsize
    if mod(i,4) == 1
        TR1((i+3)/4).TRname = Database(i).name;
    elseif mod(i,4) == 2
        TR2((i+2)/4).TRname = Database(i).name;
    elseif mod(i,4) == 3
        TR3((i+1)/4).TRname = Database(i).name;
    elseif mod(i,4) == 0
        TR4(i/4).TRname = Database(i).name;
    end
    
end

TR1_DM_hr = zeros(b_h*prod(patchSize), TR1size*sum(nTR_DM));
TR1_DH_hr = zeros(b_h*prod(patchSize), TR1size*sum(nTR_DH));


DataTemp_bicubic(length(nTR_DM)).Image = [];
RandomSamples(length(nTR_DM)).selection = [];

globalCounter = 0;
for a = 1:TR1size

    DataTemp = load(TR1(a).TRname);
    
    for i = 1:length(nTR_DM)
        
       dim = size(imresize(DataTemp.hsi(:,:,1),scale(i)));
       DataTemp_bicubic(i).Image = zeros(dim(1), dim(2), b_h);
       for l = 1:b_h
           DataTemp_bicubic(i).Image(:,:,l) = imresize(DataTemp.hsi(:,:,l),scale(i));
       end
       RandomSamples(i).selection = randperm(dim(1)*dim(2), nTR_DH(i));
    end
    
    for l = 1:length(nTR_DM)
        DataTemp_bicubic(l).Image = mat2gray(DataTemp_bicubic(l).Image);
    end
    
    tempHRrow = zeros(b_h,prod(patchSize));
    tempHRcol = zeros(b_h * prod(patchSize),1);
    
    localCounter = 0; 
    for i = 1:length(nTR_DH) 
        image = padarray(DataTemp_bicubic(i).Image,[floor(patchSize(1)/2), floor(patchSize(2)/2)], 'both', 'symmetric');
        for d = 1:nTR_DH(i)
            globalCounter = globalCounter + 1;
            tempSize = size(DataTemp_bicubic(i).Image);

            width = ceil(RandomSamples(i).selection(d)/tempSize(1));
            height = RandomSamples(i).selection(d) - tempSize(1)*(width-1);
            height = height + floor(patchSize(1)/2);
            width = width + floor(patchSize(2)/2);
            newCoordinates = [height, width];
            tempHRrow(:,:) = extractPatch(image, newCoordinates, patchSize);
            tempHRcol(:,1) = reshape(tempHRrow, [numel(tempHRrow),1]);

            if d > 0 && d <= nTR_DM(i)
                localCounter = localCounter+1;
                TR1_DM_hr(:, (a-1)*sum(nTR_DM) + localCounter) = tempHRcol;
            end

            TR1_DH_hr(:, globalCounter) = tempHRcol;
        end
    end
    
end

TR2_DM_hr = zeros(b_h*prod(patchSize), TR2size*sum(nTR_DM));
TR2_DH_hr = zeros(b_h*prod(patchSize), TR2size*sum(nTR_DH));

DataTemp_bicubic(length(nTR_DM)).Image = [];
RandomSamples(length(nTR_DM)).selection = [];

globalCounter = 0;
for a = 1:TR2size

    DataTemp = load(TR2(a).TRname);
    
    for i = 1:length(nTR_DM)
       dim = size(imresize(DataTemp.hsi(:,:,1),scale(i)));
       DataTemp_bicubic(i).Image = zeros(dim(1), dim(2), b_h);
       for l = 1:b_h
           DataTemp_bicubic(i).Image(:,:,l) = imresize(DataTemp.hsi(:,:,l),scale(i));
       end
       RandomSamples(i).selection = randperm(dim(1)*dim(2), nTR_DH(i));
    end
    
    for l = 1:length(nTR_DM)
        DataTemp_bicubic(l).Image = mat2gray(DataTemp_bicubic(l).Image);
    end
    
    tempHRrow = zeros(b_h,prod(patchSize));
    tempHRcol = zeros(b_h * prod(patchSize),1);
    
    localCounter = 0; 
    for i = 1:length(nTR_DH) 
        image = padarray(DataTemp_bicubic(i).Image,[floor(patchSize(1)/2), floor(patchSize(2)/2)], 'both', 'symmetric');
        for d = 1:nTR_DH(i)
            globalCounter = globalCounter + 1;
            tempSize = size(DataTemp_bicubic(i).Image);
            width = ceil(RandomSamples(i).selection(d)/tempSize(1));
            height = RandomSamples(i).selection(d) - tempSize(1)*(width-1);
            height = height + floor(patchSize(1)/2);
            width = width + floor(patchSize(2)/2);
            newCoordinates = [height, width];
            tempHRrow(:,:) = extractPatch(image, newCoordinates, patchSize);
            tempHRcol(:,1) = reshape(tempHRrow, [numel(tempHRrow),1]);
            
            if d > 0 && d <= nTR_DM(i)
                localCounter = localCounter+1;
                TR2_DM_hr(:, (a-1)*sum(nTR_DM) + localCounter) = tempHRcol;
            end
           
            TR2_DH_hr(:, globalCounter) = tempHRcol;
        end
    end
    
end

TR3_DM_hr = zeros(b_h*prod(patchSize), TR3size*sum(nTR_DM));
TR3_DH_hr = zeros(b_h*prod(patchSize), TR3size*sum(nTR_DH));

DataTemp_bicubic(length(nTR_DM)).Image = [];
RandomSamples(length(nTR_DM)).selection = [];

globalCounter = 0;
for a = 1:TR3size

    DataTemp = load(TR3(a).TRname);

    for i = 1:length(nTR_DM)
       dim = size(imresize(DataTemp.hsi(:,:,1),scale(i)));
       DataTemp_bicubic(i).Image = zeros(dim(1), dim(2), b_h);
       for l = 1:b_h
           DataTemp_bicubic(i).Image(:,:,l) = imresize(DataTemp.hsi(:,:,l),scale(i));
       end
       RandomSamples(i).selection = randperm(dim(1)*dim(2), nTR_DH(i));
    end
    
    for l = 1:length(nTR_DM)
        DataTemp_bicubic(l).Image = mat2gray(DataTemp_bicubic(l).Image);
    end
    
    tempHRrow = zeros(b_h,prod(patchSize));
    tempHRcol = zeros(b_h * prod(patchSize),1);
    
    localCounter = 0; 
    for i = 1:length(nTR_DH) 
        image = padarray(DataTemp_bicubic(i).Image,[floor(patchSize(1)/2), floor(patchSize(2)/2)], 'both', 'symmetric');
        for d = 1:nTR_DH(i)
            globalCounter = globalCounter + 1;
            tempSize = size(DataTemp_bicubic(i).Image);
            width = ceil(RandomSamples(i).selection(d)/tempSize(1));
            height = RandomSamples(i).selection(d) - tempSize(1)*(width-1);
            height = height + floor(patchSize(1)/2);
            width = width + floor(patchSize(2)/2);
            newCoordinates = [height, width];
            tempHRrow(:,:) = extractPatch(image, newCoordinates, patchSize);
            tempHRcol(:,1) = reshape(tempHRrow, [numel(tempHRrow),1]);
            
            if d > 0 && d <= nTR_DM(i)
                localCounter = localCounter+1;
                TR3_DM_hr(:, (a-1)*sum(nTR_DM) + localCounter) = tempHRcol;
            end
           
            TR3_DH_hr(:, globalCounter) = tempHRcol;
        end
    end
    
end

TR4_DM_hr = zeros(b_h*prod(patchSize), TR4size*sum(nTR_DM));
TR4_DH_hr = zeros(b_h*prod(patchSize), TR4size*sum(nTR_DH));

DataTemp_bicubic(length(nTR_DM)).Image = [];
RandomSamples(length(nTR_DM)).selection = [];

globalCounter = 0;
for a = 1:TR4size

    DataTemp = load(TR4(a).TRname);
    
    for i = 1:length(nTR_DM)
       dim = size(imresize(DataTemp.hsi(:,:,1),scale(i)));
       DataTemp_bicubic(i).Image = zeros(dim(1), dim(2), b_h);
       for l = 1:b_h
           DataTemp_bicubic(i).Image(:,:,l) = imresize(DataTemp.hsi(:,:,l),scale(i));
       end
       RandomSamples(i).selection = randperm(dim(1)*dim(2), nTR_DH(i));
    end

    for l = 1:length(nTR_DM)
        DataTemp_bicubic(l).Image = mat2gray(DataTemp_bicubic(l).Image);
    end
    
    tempHRrow = zeros(b_h,prod(patchSize));
    tempHRcol = zeros(b_h * prod(patchSize),1);
    
    localCounter = 0; 
    for i = 1:length(nTR_DH) 
        image = padarray(DataTemp_bicubic(i).Image,[floor(patchSize(1)/2), floor(patchSize(2)/2)], 'both', 'symmetric');
        for d = 1:nTR_DH(i)
            globalCounter = globalCounter + 1;

            tempSize = size(DataTemp_bicubic(i).Image);

            width = ceil(RandomSamples(i).selection(d)/tempSize(1));
            height = RandomSamples(i).selection(d) - tempSize(1)*(width-1);
            height = height + floor(patchSize(1)/2);
            width = width + floor(patchSize(2)/2);
            newCoordinates = [height, width];
            tempHRrow(:,:) = extractPatch(image, newCoordinates, patchSize);
            tempHRcol(:,1) = reshape(tempHRrow, [numel(tempHRrow),1]);
            
            if d > 0 && d <= nTR_DM(i)
                localCounter = localCounter+1;
                TR4_DM_hr(:, (a-1)*sum(nTR_DM) + localCounter) = tempHRcol;
            end
           
            TR4_DH_hr(:, globalCounter) = tempHRcol;
        end
    end
    
end

shuffle = randperm(size(TR1_DM_hr,2));
DataSplit.A.TR_DM_hr = TR1_DM_hr(:,shuffle);

shuffle = randperm(size(TR1_DH_hr,2));
DataSplit.A.TR_DH_hr = TR1_DH_hr(:,shuffle);

DataSplit.A.TRname = TR1;

shuffle = randperm(size(TR2_DM_hr,2));
DataSplit.B.TR_DM_hr = TR2_DM_hr(:,shuffle);

shuffle = randperm(size(TR2_DH_hr,2));
DataSplit.B.TR_DH_hr = TR2_DH_hr(:,shuffle);

DataSplit.B.TRname = TR2;

shuffle = randperm(size(TR3_DM_hr,2));
DataSplit.C.TR_DM_hr = TR3_DM_hr(:,shuffle);

shuffle = randperm(size(TR3_DH_hr,2));
DataSplit.C.TR_DH_hr = TR3_DH_hr(:,shuffle);

DataSplit.C.TRname = TR3;

shuffle = randperm(size(TR4_DM_hr,2));
DataSplit.D.TR_DM_hr = TR4_DM_hr(:,shuffle);

shuffle = randperm(size(TR4_DH_hr,2));
DataSplit.D.TR_DH_hr = TR4_DH_hr(:,shuffle);

DataSplit.D.TRname = TR4;

DataSplit.noSample_DM= nTR_DM;
DataSplit.noSample_DH = nTR_DH;
DataSplit.patchSize = patchSize;
DataSplit.BicubicScale = scale;

nameA = 'TrainTest_SpecTF.mat';
save([dicpath,nameA], 'DataSplit', '-v7.3');
disp('************** Training sets are build *************');

clearvars   a b c DBsize i temp TR1size TR2size TR3size ...
            TR4size shuffle temp
end