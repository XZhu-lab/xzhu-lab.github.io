function [output,Testing_time] = Spectral_reconstruction(m1,h1,m2,SRF_trans_matrix,savepath)

temp = load([savepath,'Dicpairs_SpecTF.mat']);
Dict_DH = temp.dictionary;

bh = size(h1,3);
bm = size(m1,3);

[~,mean_m,std_m]= NSF(m1);
[~,mean_h,std_h] = NSF(h1);

patchSize_DH =  Dict_DH.A.D_DH.patchSize; 
D_hr_DH = Dict_DH.A.D_DH.D_hr; 
Aplus_PPs = Dict_DH.A.D_DH.Aplus_PPs;
tic

featureDim_lr = bm * prod(patchSize_DH); 
featuredm = padarray(((m2 -mean_m)./std_m), [floor(patchSize_DH(1)/2), floor(patchSize_DH(2)/2)], 'both', 'symmetric');

isize = size(h1);
features_lr = zeros(featureDim_lr, isize(1)*isize(2));
tempHRrow = zeros(bh, prod(patchSize_DH)); 
tempLRrow = zeros(bm, prod(patchSize_DH)); 
tempLRcol = zeros(bm*prod(patchSize_DH),1); 
for a = 1:isize(1)
    for b = 1:isize(2)
        height = a + floor(patchSize_DH(1)/2);
        width = b + floor(patchSize_DH(2)/2);
        newCoordinates = [height, width];
        tempLRrow(:,:) = extractPatch(featuredm, newCoordinates, patchSize_DH);
        tempLRcol(:,1) = reshape(tempLRrow, [numel(tempLRrow),1]);

        features_lr(:, (a-1)*isize(2)+b) = tempLRcol;        
    end
end

features_lr_norm = normc(features_lr);

IniD = SRF_trans_matrix'*reshape(D_hr_DH, [bh, size(D_hr_DH,2)*prod(patchSize_DH)]);
IniD_norm = normc(reshape(IniD, [bm*prod(patchSize_DH), size(D_hr_DH,2)]));

IDX = knnsearch(IniD_norm', features_lr_norm','NSMethod', 'euclidean');
image_rec = zeros(bh, numel(h1(:,:,1)));


for i = 1:length(IDX)
    image_rec(:,i) = Aplus_PPs{IDX(i)}*features_lr(:,i);
end

output_feature = zeros(isize(1), isize(2),bh);
for p = 1:isize(1)
    output_feature(p,:,:) = image_rec(:,(p-1)*isize(2)+1:(p)*isize(2))';
end


output = output_feature.*std_h +mean_h;

%% end timer
Testing_time = toc;
fprintf('Testing time is %.4f s\n', Testing_time);


end