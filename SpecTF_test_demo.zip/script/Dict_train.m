function Dict_train(dicpath,SRF_trans_matrix,param)

iternum = param.iternum;
b_m = param.bm;
b_h = param.bh;

set1_DM = param.set(1);
set2_DM = param.set(2);
set1_DH = param.set(3);
set2_DH = param.set(4);

% filename of training set
TRTSset_path = dicpath;
TRname = 'TrainTest_SpecTF.mat';

%% Initialization of variables and data

settings_DM = zeros(length(set1_DM)*length(set2_DM),2);
for f = 1:length(set1_DM)
    for g = 1:length(set2_DM)
        settings_DM((f-1)*length(set2_DM)+g,:) = [set1_DM(f),set2_DM(g)];
    end
end

settings_DH = zeros(length(set1_DH)*length(set2_DH),2);
for f = 1:length(set1_DH)
    for g = 1:length(set2_DH)
        settings_DH((f-1)*length(set2_DH)+g,:) = [set1_DH(f),set2_DH(g)];
    end
end

numb = size(settings_DM,1);
storage_DM(numb).A.D_DM = [];
storage_DM(numb).B.D_DM = [];
storage_DM(numb).C.D_DM = [];
storage_DM(numb).D.D_DM = [];
storage_DM(numb).TRname = [];

disp('*********** Start building dictionaries ************');
tic
for p = 1:size(settings_DM,1)
   
        m = settings_DM(p,2);
        k = settings_DM(p,1);

        Temp = load([TRTSset_path TRname]);
        DataSplit = Temp.DataSplit;

        patchSize = DataSplit.patchSize;
        bicubicScale = DataSplit.BicubicScale;

        TR_DM_A = [DataSplit.B.TR_DM_hr, DataSplit.C.TR_DM_hr, DataSplit.D.TR_DM_hr,];
        TR_DM_B = [DataSplit.A.TR_DM_hr, DataSplit.C.TR_DM_hr, DataSplit.D.TR_DM_hr,];
        TR_DM_C = [DataSplit.A.TR_DM_hr, DataSplit.B.TR_DM_hr, DataSplit.D.TR_DM_hr,];
        TR_DM_D = [DataSplit.A.TR_DM_hr, DataSplit.B.TR_DM_hr, DataSplit.C.TR_DM_hr,];

        [D_DM_A] = CDL_m(TR_DM_A, k, m, iternum, patchSize);
        [D_DM_B] = CDL_m(TR_DM_B, k, m, iternum, patchSize);
        [D_DM_C] = CDL_m(TR_DM_C, k, m, iternum, patchSize);
        [D_DM_D] = CDL_m(TR_DM_D, k, m, iternum, patchSize);

        storage_DM(p).A.D_DM = D_DM_A;
        storage_DM(p).B.D_DM = D_DM_B;
        storage_DM(p).C.D_DM = D_DM_C;
        storage_DM(p).D.D_DM = D_DM_D;
        storage_DM(p).TRname = TRname;
        
end

%%

numb = size(settings_DH,1);
storage_DH(numb).A.D_DM = [];
storage_DH(numb).A.D_DH = [];
storage_DH(numb).B.D_DM = [];
storage_DH(numb).B.D_DH = [];
storage_DH(numb).C.D_DM = [];
storage_DH(numb).C.D_DH = [];
storage_DH(numb).D.D_DM = [];
storage_DH(numb).D.D_DH = [];
storage_DH(numb).TRname = [];

for i = 1:size(settings_DM,1)
    D_DM_A = storage_DM(i).A.D_DM;
    D_DM_B = storage_DM(i).B.D_DM;
    D_DM_C = storage_DM(i).C.D_DM;
    D_DM_D = storage_DM(i).D.D_DM;
    D_hr_A = D_DM_A.D_hr;
    D_hr_B = D_DM_B.D_hr;
    D_hr_C = D_DM_C.D_hr;
    D_hr_D = D_DM_D.D_hr;
    
    for r = 1:size(settings_DH,1)


            lambda = settings_DH(r,1);
            clustersz = settings_DH(r,2);

            Temp = load([TRTSset_path TRname]);
            DataSplit = Temp.DataSplit;

            patchSize = DataSplit.patchSize;
            bicubicScale = DataSplit.BicubicScale;

            TR_DH_A = [DataSplit.B.TR_DH_hr, DataSplit.C.TR_DH_hr, DataSplit.D.TR_DH_hr];
            TR_DH_B = [DataSplit.A.TR_DH_hr, DataSplit.C.TR_DH_hr, DataSplit.D.TR_DH_hr];
            TR_DH_C = [DataSplit.A.TR_DH_hr, DataSplit.B.TR_DH_hr, DataSplit.D.TR_DH_hr];
            TR_DH_D = [DataSplit.A.TR_DH_hr, DataSplit.B.TR_DH_hr, DataSplit.C.TR_DH_hr];
   
            [D_DH_A] = CDL_h(D_hr_A, TR_DH_A, lambda, clustersz, patchSize,SRF_trans_matrix,b_m,b_h);
            [D_DH_B] = CDL_h(D_hr_B, TR_DH_B, lambda, clustersz, patchSize,SRF_trans_matrix,b_m,b_h);
            [D_DH_C] = CDL_h(D_hr_C, TR_DH_C, lambda, clustersz, patchSize,SRF_trans_matrix,b_m,b_h);
            [D_DH_D] = CDL_h(D_hr_D, TR_DH_D, lambda, clustersz, patchSize,SRF_trans_matrix,b_m,b_h);

            storage_DH(r).A.D_DM = D_DM_A;
            storage_DH(r).A.D_DH = D_DH_A;
            storage_DH(r).B.D_DM = D_DM_B;
            storage_DH(r).B.D_DH = D_DH_B;
            storage_DH(r).C.D_DM = D_DM_C;
            storage_DH(r).C.D_DH = D_DH_C;
            storage_DH(r).D.D_DM = D_DM_D;
            storage_DH(r).D.D_DH = D_DH_D;
            storage_DH(r).TRname = TRname;
            

    end
    
    for q = 1:size(settings_DH,1)

        dictionary = storage_DH(q);
        dictname = 'Dicpairs_SpecTF.mat';
        save([dicpath,dictname], 'dictionary', '-v7.3')
    end
     
end

toc
Training_time = toc; 
disp('********* Finished building dictionaries ***********');
fprintf('Training time is %.4f s\n', Training_time);

%%
clearvars   f g i numb q temp D_DM_A D_DM_B 
end