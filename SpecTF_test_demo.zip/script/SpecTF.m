function [h2_est, testing_time] = SpecTF(m1,h1,m2,param)


%%% Working directory manually, but please remind that
datapath = pwd; %%% pwd is the current working directory
dicpath = [pwd,'\dic\'];
savepath = pwd;

[SpectralDegradation] = SRFcal(param.SRF_m,param.SRF_h);
Build_dataset(m1,h1,datapath,dicpath,param);

Dict_train(dicpath,SpectralDegradation,param); 

[h2_est,testing_time] = Spectral_reconstruction(m1,h1,m2,SpectralDegradation,dicpath);

end

