%% Spectrotemporal Fusion (SpecTF)
%
%  Generate frequent hyperspectral satellite imagery
%
%  If you use this code please cite:
%
%  [1] Zhao, S., Zhu, X., Tan, X., & Tian, J. (2025). Spectrotemporal 
%  fusion: Generation of frequent hyperspectral satellite imagery. 
%  Remote Sensing of Environment, 319, 114639. 
%  https://doi.org/10.1016/j.rse.2025.114639
%
%
% If you have any questions, pelase contact:
%
% xiaolin.zhu@polyu.edu.hk (Zhu, X.)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input：MSI at T1, HSI at T1 and MSI at T2
% Output: HSI at T2


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Before using this code, please make sure all the preprocessing operations
% (including geo-registration, denoising......) have been done.
% If the spatial resolution of MSI ≠ the spatial resolution of HSI,
% please resample MSI to the spatial resolution of HSI
% e.g. If you want to fuse Sentinel-2 and PRISMA, please resample
% Sentinel-2 to 30 m before fusion.


%clear;clc;close all;
addpath(genpath('basic_function'));
addpath(genpath('script'));
addpath(genpath('test_data'));
addpath(genpath('satellite_parameter'));
%%% Input reflectance

%%% !!!!! Please download corresponding test data !!!!
%%% download link: https://pan.baidu.com/s/1GmdYqkO0-dg2zkuw3aa3Hg?pwd=nkfz  
%%% password: nkfz
load m1.mat;   %%% take resampled Sentinel-2 （resampled to 30m）for example
load h1.mat;   %%% take resampled Prisma for example
load m2.mat;
% load h2.mat;


[m,n,bh] = size(h1); bm = size(m1,3);


%%% Load spectral response function

load srf_prisma.mat;
load srf_s2_b.mat;


%%% Setting parameters
param.bm = bm;     
param.bh = bh ; 
param.SRF_m = srf_s2_b;     
param.SRF_h = srf_prisma ;     
param.iternum = 40;   %%% Number of iterations
param.samples = 100;  %%% Number of randomly selected samples
param.w = 0.5000;
param.patchsize = [3,3];
param.set = [2,128,0.1,256];

%%% Spectrotemporal fusion
[h2_est, running_time] = SpecTF(m1,h1,m2,param);




